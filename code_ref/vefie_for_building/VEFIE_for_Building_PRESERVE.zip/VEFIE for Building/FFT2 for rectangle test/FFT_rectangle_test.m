%FFT_test

clear all
close all
clc


space = [1:6;7:12;13:18]

G_vectorW(1:18)= space(:,:)
G_vectorL(1:18)= space(:,:).'

N = length(space(1,:)) %SpaceLength
M = length(space(:,1))  %PaceWidth

Vector = 10*rand(N*M,1)

if 1 == 1 %create G_matrix with big block's    
    for i = 1:M % Create firt row of toeplitz
        G_matrixL(:,(i-1)*N+1:i*N) = toeplitz(G_vectorL((i-1)*N+1:i*N),G_vectorL((i-1)*N+1:i*N));
    end

    for i = 2:M % Create rest of the rows
        for j = 1:M
           G_matrixL((i-1)*N+1:i*N,(j-1)*N+1:j*N) = G_matrixL(1:N,abs(i-j)*N+1:abs(i-j)*N+1+N-1);      
        end
    end
end

if 1 == 1 %create G_matix with little block's
    for i = 1:N % Create firt row of toeplitz
        G_matrixW(:,(i-1)*M+1:i*M) = toeplitz(G_vectorW((i-1)*M+1:i*M),G_vectorW((i-1)*M+1:i*M));
    end

    for i = 2:N % Create rest of the rows
        for j = 1:N
           G_matrixW((i-1)*M+1:i*M,(j-1)*M+1:j*M) = G_matrixW(1:M,abs(i-j)*M+1:abs(i-j)*M+1+M-1);      
        end
    end
end
Using_function = BMT_FFT(G_vectorL,Vector,N)
full_calculation = (G_matrixL * Vector)

Using_fuction = BMT_FFT(G_vectorW,Vector,M)
full_calculation = (G_matrixW * Vector)
